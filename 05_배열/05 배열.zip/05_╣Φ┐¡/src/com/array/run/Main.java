package com.array.run;

import com.array.controller.ArrayController;

public class Main {
	public static void main(String[] args) {
		//new ArrayController().basicArray();
		//new ArrayController().arraysCopyTest();
		//new ArrayController().doubleArray();
		new ArrayController().extraTest();
	}
}
