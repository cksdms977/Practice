package com.array.run;

import java.util.concurrent.ArrayBlockingQueue;

import com.array.controller.*;

public class Main {
public static void main(String[] args) {
		//new ArrayController().basicArray();
		//new ArrayController().practice4();
		//new ArrayController().practice6();
		//new ArrayController().practice7();
		//new ArrayController().practice8();
		//new ArrayController().practice9();
		new ArrayController().practice10();
}
}
