package com.ploy.model.vo;

import com.ploy.controller.*;

public class PloyTest extends PloyTestParent {
	
	private String childData;
	
	public void setChildData(String childData) {
		this.childData = childData;
				
	}
	
	public String getChildData() {
		return this.childData;
	}
		
}
