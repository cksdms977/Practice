package com.ploy.model.vo;

import com.ploy.*;

public class PloyTestParent {
	private String parentData;
	
	
	
	
	public void setParentData(String parentData) {
		this.parentData = parentData;
	}
	
	public String getParentData() {
		return this.parentData;
	}

}
