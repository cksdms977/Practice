package com.ploy.model.vo;

public class PloyTest2 extends PloyTestParent{
	
	private String childData;
	
	public void setChildData(String childData) {
		this.childData = childData;
				
	}
	
	public String getChildData() {
		return this.childData;
	}
	
}
