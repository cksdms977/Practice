package com.ploy.model.vo;

public class AbstractChildClass extends AbstarctClassTest{

	
	
	
}
