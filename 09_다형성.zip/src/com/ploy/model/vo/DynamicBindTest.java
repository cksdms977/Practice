package com.ploy.model.vo;

public class DynamicBindTest {
	// 동적바인딩 적용하기
	// 오버라이딩된 메소드가 있으면 자식 메소드가 실행되는 것
	
	@Override
	public String toString() {
		return " dynamicBindTest gogo! ";
		
	}
	
	
}
