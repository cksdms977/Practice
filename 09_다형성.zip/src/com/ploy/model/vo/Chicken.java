package com.ploy.model.vo;

public  class Chicken extends Animal{
	
	
	public Chicken() {
		// TODO Auto-generated constructor stub
	}

	
	
	
	@Override
	public void bark() {
		System.out.println("꼬끼오!");
		
	}
	





}
