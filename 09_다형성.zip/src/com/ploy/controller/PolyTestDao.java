package com.ploy.controller;

import com.ploy.controller.*;
import com.ploy.model.vo.Person;

public class PolyTestDao {
		
		private Person p;
		
		public  PolyTestDao() {
			// TODO Auto-generated constructor stub
		}

		public  PolyTestDao(Person p) {
			super();
			this.p = p;
			
		}
		
		
		
		
}
	

