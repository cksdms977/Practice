package com.repeate.run;

import com.repeate.controller.RepeateController;

public class Main {
	public static void main(String[] args) {
		//new RepeateController().basicRepeat();
		//new RepeateController().forApplication();
		//new RepeateController().empInputDate();
		//new RepeateController().forApplication2();
		//new RepeateController().forInfor();
		//new RepeateController().whileTest();
		//new RepeateController().whileCalculater();
		//new RepeateController().continueBreakTest();
		new RepeateController().randomTest();
		
	}
}
