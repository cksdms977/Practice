package com.bs.practice.run;

import com.bs.practice.array.ArrayPractice;

public class Run {
	public static void main(String[] args) {
		//new ArrayPractice().practice1();
		//new ArrayPractice().practice2();
		//new ArrayPractice().practice3();
		//new ArrayPractice().practice4();
		//new ArrayPractice().practice5();
		//new ArrayPractice().practice6();
		//new ArrayPractice().practice7();
		//new ArrayPractice().practice8();
		//new ArrayPractice().practic9();
		//new ArrayPractice().practice10();
		//new ArrayPractice().practice11();
		//new ArrayPractice().practice12();
		//new ArrayPractice().practice13();
		//new ArrayPractice().practice14();
		new ArrayPractice().practice15();
		//new ArrayPractice().practice16();
		//new ArrayPractice().practice17();
		
		
	}

}
