package com.bs.practice.chap02.run;

import com.bs.practice.chap02.loop.LoopPractice;

public class Run {
	public static void main(String[] args) {
		//new LoopPractice().practice1();
		//new LoopPractice().practice2();
		//new LoopPractice().practice3();
		//new LoopPractice().practice4();
		//new LoopPractice().practice5();
		//new LoopPractice().practice6();
		//new LoopPractice().practice7();
		//new LoopPractice().practice8();
		//new LoopPractice().practice9();
		//new LoopPractice().practice10();
		//new LoopPractice().practice11();
		//new LoopPractice().practice11();
		//new LoopPractice().practice12();
		//new LoopPractice().practice13();
		//new LoopPractice().practice14();
		//new LoopPractice().practice15();
		//new LoopPractice().practice16();
		//new LoopPractice().practice17();
		//new LoopPractice().practice18();
		//new LoopPractice().practice19();
		//new LoopPractice().practice20();
		//new LoopPractice().practice21();
		//new LoopPractice().practice22();
		//new LoopPractice().practice23();
		//new LoopPractice().practice24();
		//new LoopPractice().practice25();
		
		
		
	}
}
