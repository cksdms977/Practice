package com.bs.run;

import com.bs.mod.vo.Member;

public class MemberDao {

	// 2개 게시글 저장
	Member mm = new Member();
	
	
	
	
	
	
}
