package com.inherit.model.vo;



public class OverrideParent {
	
	public final void printMsg() {
		System.out.println("Override Parent");
		
		
		
		
	}
}
