package com.bs; // (상단에는)패키지가 선언 
// (클래스 부문과 패키지 부문 사이에는)다른패키지(경로)에서 제공되는 클래스를 이용할 수 있게하는 import구문 작성
// import java.util,Date; //(가져올 패키지 이름 쓰면 됨)
/* 여러라인으로 설명을 작성할때 사용하는 주석 */
public class HelloWorld { // 클래스 선언부
	public static void main (String[] args) {
		System.out.println("Hello Java");
		
	}
}
