package com.bs.variable;

public class OverflowTest {
	public static void main(String[] args) {
		// 오버플로우 테스트 (overflowtest)
		
//		byte b = 100; 이렇게 하면 계속 반복하게 됨.ㄴ 
		int b = 100;
	for (int i = 0; i < 10000; i++) {
		b +=1; // b=b+1;이라는 뜻
		System.out.println(b);
	
		
		
		
		
	}
	}

}
