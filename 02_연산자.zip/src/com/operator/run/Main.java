package com.operator.run;
// 프로젝트를 실행하는 기능을 하는 main 클래스 -> main 메소드를 갖는다.

import com.operator.controller.OperatorController;


public class Main {
	public static void main(String[] args) {
		//new OperatorController().singleOp();
		//new OperatorController().calculatorOp();
		//new OperatorController().calc();
		//new OperatorController().compareOp();
		//new OperatorController().testStr();
		new OperatorController().check();
		//new OperatorController().logicOp();
		//new OperatorController().complexOp();
		//new OperatorController().calcGrade();
		//new OperatorController().inputMsg();
		//new OperatorController().thirdOp();
	
	
	}

}
