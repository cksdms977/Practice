package com.control.run;

import com.control.controller.ConditionController;

public class Main {
	public static void main(String[] args) {
		//new ConditionController().ifTest();
		//new ConditionController().checkNumber();
		//new ConditionController().testName();
		//new ConditionController().logincheck();
		//new ConditionController().ifelseTest();
		//new ConditionController().oddeven();
		//new ConditionController().enrollMember();
		//new ConditionController().ifelseifTest();
		//new ConditionController().switchTest();
		new ConditionController().ex_test();
	
	
	}

}
