package com.repeate.run;

import com.repeate.controller.RepeateController;

public class Main {
	public static void main(String[] args) {
		new RepeateController().basicRepeat();
		
		
		
		
		
	}
}
