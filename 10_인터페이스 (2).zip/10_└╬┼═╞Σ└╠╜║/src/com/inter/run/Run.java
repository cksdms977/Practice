package com.inter.run;

import com.inter.controller.InterfaceController;

public class Run {
	public static void main(String[] args) {
		
		new InterfaceController().basicInterface();
		new InterfaceController().interInheritTest();
		new InterfaceController().extraInterface();;
		
		
	}
}
