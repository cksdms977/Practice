package com.inter.common;

@FunctionalInterface

public interface StringInterface {
		String strCheck(String data);
		
}
