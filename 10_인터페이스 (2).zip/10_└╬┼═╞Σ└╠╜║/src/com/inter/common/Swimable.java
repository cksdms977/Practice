package com.inter.common;

public interface Swimable {
	void swim();
}
