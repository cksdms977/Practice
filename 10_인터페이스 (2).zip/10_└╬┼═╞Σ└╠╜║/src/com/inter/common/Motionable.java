package com.inter.common;

public interface Motionable {
	void bark();
	void forward();
	void back();
	void jump();
	
	
}
