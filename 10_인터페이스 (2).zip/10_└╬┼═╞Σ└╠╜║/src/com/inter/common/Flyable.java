package com.inter.common;

public interface Flyable {
	void fly();
	
	
	
}
