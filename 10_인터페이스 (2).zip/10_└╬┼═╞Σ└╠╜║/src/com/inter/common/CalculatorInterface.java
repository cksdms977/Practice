package com.inter.common;

@FunctionalInterface

public interface CalculatorInterface {
	void calc(int su, int su2);
//	int calc2(int a, int b); // 하나만 저장해야 함
	
}
