package com.inter.common;

public interface PrinterDriver {
	void print();
	
	
}
