package com.inter.modle.vo;

public class Dolphin extends Animal{

}
